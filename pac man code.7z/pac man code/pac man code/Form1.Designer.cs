﻿namespace pac_man_code
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtScore = new System.Windows.Forms.Label();
            this.gameTimer = new System.Windows.Forms.Timer(this.components);
            this.pictureBox53 = new System.Windows.Forms.PictureBox();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.pictureBox41 = new System.Windows.Forms.PictureBox();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox52 = new System.Windows.Forms.PictureBox();
            this.pictureBox46 = new System.Windows.Forms.PictureBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.pictureBox51 = new System.Windows.Forms.PictureBox();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox50 = new System.Windows.Forms.PictureBox();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox49 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox67 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox66 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox65 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox64 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.pictureBox63 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox62 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox61 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox60 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox59 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox58 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox57 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.coin = new System.Windows.Forms.PictureBox();
            this.pacman = new System.Windows.Forms.PictureBox();
            this.pinkghost = new System.Windows.Forms.PictureBox();
            this.yellowghost = new System.Windows.Forms.PictureBox();
            this.redghost = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pacman)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pinkghost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yellowghost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.redghost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtScore
            // 
            this.txtScore.AutoSize = true;
            this.txtScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtScore.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.txtScore.Location = new System.Drawing.Point(2, 2);
            this.txtScore.Name = "txtScore";
            this.txtScore.Size = new System.Drawing.Size(68, 20);
            this.txtScore.TabIndex = 0;
            this.txtScore.Text = "score 0";
            // 
            // gameTimer
            // 
            this.gameTimer.Interval = 20;
            this.gameTimer.Tick += new System.EventHandler(this.mainGameTimer);
            // 
            // pictureBox53
            // 
            this.pictureBox53.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox53.Location = new System.Drawing.Point(386, 262);
            this.pictureBox53.Name = "pictureBox53";
            this.pictureBox53.Size = new System.Drawing.Size(22, 22);
            this.pictureBox53.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox53.TabIndex = 7;
            this.pictureBox53.TabStop = false;
            this.pictureBox53.Tag = "coin";
            this.pictureBox53.Visible = false;
            // 
            // pictureBox47
            // 
            this.pictureBox47.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox47.Location = new System.Drawing.Point(132, 262);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(22, 22);
            this.pictureBox47.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox47.TabIndex = 7;
            this.pictureBox47.TabStop = false;
            this.pictureBox47.Tag = "coin";
            this.pictureBox47.Visible = false;
            // 
            // pictureBox41
            // 
            this.pictureBox41.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox41.Location = new System.Drawing.Point(302, 527);
            this.pictureBox41.Name = "pictureBox41";
            this.pictureBox41.Size = new System.Drawing.Size(22, 22);
            this.pictureBox41.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox41.TabIndex = 7;
            this.pictureBox41.TabStop = false;
            this.pictureBox41.Tag = "coin";
            this.pictureBox41.Visible = false;
            // 
            // pictureBox35
            // 
            this.pictureBox35.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox35.Location = new System.Drawing.Point(302, 386);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(22, 22);
            this.pictureBox35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox35.TabIndex = 7;
            this.pictureBox35.TabStop = false;
            this.pictureBox35.Tag = "coin";
            this.pictureBox35.Visible = false;
            // 
            // pictureBox29
            // 
            this.pictureBox29.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox29.Location = new System.Drawing.Point(302, 113);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(22, 22);
            this.pictureBox29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox29.TabIndex = 7;
            this.pictureBox29.TabStop = false;
            this.pictureBox29.Tag = "coin";
            this.pictureBox29.Visible = false;
            // 
            // pictureBox52
            // 
            this.pictureBox52.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox52.Location = new System.Drawing.Point(470, 262);
            this.pictureBox52.Name = "pictureBox52";
            this.pictureBox52.Size = new System.Drawing.Size(22, 22);
            this.pictureBox52.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox52.TabIndex = 7;
            this.pictureBox52.TabStop = false;
            this.pictureBox52.Tag = "coin";
            this.pictureBox52.Visible = false;
            // 
            // pictureBox46
            // 
            this.pictureBox46.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox46.Location = new System.Drawing.Point(216, 262);
            this.pictureBox46.Name = "pictureBox46";
            this.pictureBox46.Size = new System.Drawing.Size(22, 22);
            this.pictureBox46.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox46.TabIndex = 7;
            this.pictureBox46.TabStop = false;
            this.pictureBox46.Tag = "coin";
            this.pictureBox46.Visible = false;
            // 
            // pictureBox40
            // 
            this.pictureBox40.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox40.Location = new System.Drawing.Point(386, 527);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(22, 22);
            this.pictureBox40.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox40.TabIndex = 7;
            this.pictureBox40.TabStop = false;
            this.pictureBox40.Tag = "coin";
            this.pictureBox40.Visible = false;
            // 
            // pictureBox51
            // 
            this.pictureBox51.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox51.Location = new System.Drawing.Point(345, 262);
            this.pictureBox51.Name = "pictureBox51";
            this.pictureBox51.Size = new System.Drawing.Size(22, 22);
            this.pictureBox51.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox51.TabIndex = 7;
            this.pictureBox51.TabStop = false;
            this.pictureBox51.Tag = "coin";
            this.pictureBox51.Visible = false;
            this.pictureBox51.Click += new System.EventHandler(this.pictureBox51_Click);
            // 
            // pictureBox45
            // 
            this.pictureBox45.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox45.Location = new System.Drawing.Point(91, 262);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(22, 22);
            this.pictureBox45.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox45.TabIndex = 7;
            this.pictureBox45.TabStop = false;
            this.pictureBox45.Tag = "coin";
            this.pictureBox45.Visible = false;
            // 
            // pictureBox39
            // 
            this.pictureBox39.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox39.Location = new System.Drawing.Point(261, 527);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(22, 22);
            this.pictureBox39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox39.TabIndex = 7;
            this.pictureBox39.TabStop = false;
            this.pictureBox39.Tag = "coin";
            this.pictureBox39.Visible = false;
            // 
            // pictureBox34
            // 
            this.pictureBox34.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox34.Location = new System.Drawing.Point(386, 386);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(22, 22);
            this.pictureBox34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox34.TabIndex = 7;
            this.pictureBox34.TabStop = false;
            this.pictureBox34.Tag = "coin";
            this.pictureBox34.Visible = false;
            // 
            // pictureBox33
            // 
            this.pictureBox33.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox33.Location = new System.Drawing.Point(261, 386);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(22, 22);
            this.pictureBox33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox33.TabIndex = 7;
            this.pictureBox33.TabStop = false;
            this.pictureBox33.Tag = "coin";
            this.pictureBox33.Visible = false;
            // 
            // pictureBox25
            // 
            this.pictureBox25.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox25.Location = new System.Drawing.Point(386, 113);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(22, 22);
            this.pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox25.TabIndex = 7;
            this.pictureBox25.TabStop = false;
            this.pictureBox25.Tag = "coin";
            this.pictureBox25.Visible = false;
            // 
            // pictureBox28
            // 
            this.pictureBox28.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox28.Location = new System.Drawing.Point(261, 113);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(22, 22);
            this.pictureBox28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox28.TabIndex = 7;
            this.pictureBox28.TabStop = false;
            this.pictureBox28.Tag = "coin";
            this.pictureBox28.Visible = false;
            // 
            // pictureBox50
            // 
            this.pictureBox50.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox50.Location = new System.Drawing.Point(426, 262);
            this.pictureBox50.Name = "pictureBox50";
            this.pictureBox50.Size = new System.Drawing.Size(22, 22);
            this.pictureBox50.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox50.TabIndex = 7;
            this.pictureBox50.TabStop = false;
            this.pictureBox50.Tag = "coin";
            this.pictureBox50.Visible = false;
            // 
            // pictureBox44
            // 
            this.pictureBox44.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox44.Location = new System.Drawing.Point(172, 262);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(22, 22);
            this.pictureBox44.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox44.TabIndex = 7;
            this.pictureBox44.TabStop = false;
            this.pictureBox44.Tag = "coin";
            this.pictureBox44.Visible = false;
            // 
            // pictureBox38
            // 
            this.pictureBox38.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox38.Location = new System.Drawing.Point(342, 527);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(22, 22);
            this.pictureBox38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox38.TabIndex = 7;
            this.pictureBox38.TabStop = false;
            this.pictureBox38.Tag = "coin";
            this.pictureBox38.Visible = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox21.Location = new System.Drawing.Point(302, 12);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(22, 22);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox21.TabIndex = 7;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Tag = "coin";
            this.pictureBox21.Visible = false;
            // 
            // pictureBox55
            // 
            this.pictureBox55.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox55.Location = new System.Drawing.Point(588, 262);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(22, 22);
            this.pictureBox55.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox55.TabIndex = 7;
            this.pictureBox55.TabStop = false;
            this.pictureBox55.Tag = "coin";
            this.pictureBox55.Visible = false;
            // 
            // pictureBox54
            // 
            this.pictureBox54.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox54.Location = new System.Drawing.Point(549, 262);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(22, 22);
            this.pictureBox54.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox54.TabIndex = 7;
            this.pictureBox54.TabStop = false;
            this.pictureBox54.Tag = "coin";
            this.pictureBox54.Visible = false;
            // 
            // pictureBox49
            // 
            this.pictureBox49.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox49.Location = new System.Drawing.Point(510, 262);
            this.pictureBox49.Name = "pictureBox49";
            this.pictureBox49.Size = new System.Drawing.Size(22, 22);
            this.pictureBox49.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox49.TabIndex = 7;
            this.pictureBox49.TabStop = false;
            this.pictureBox49.Tag = "coin";
            this.pictureBox49.Visible = false;
            // 
            // pictureBox32
            // 
            this.pictureBox32.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox32.Location = new System.Drawing.Point(342, 386);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(22, 22);
            this.pictureBox32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox32.TabIndex = 7;
            this.pictureBox32.TabStop = false;
            this.pictureBox32.Tag = "coin";
            this.pictureBox32.Visible = false;
            // 
            // pictureBox43
            // 
            this.pictureBox43.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox43.Location = new System.Drawing.Point(256, 262);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(22, 22);
            this.pictureBox43.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox43.TabIndex = 7;
            this.pictureBox43.TabStop = false;
            this.pictureBox43.Tag = "coin";
            this.pictureBox43.Visible = false;
            // 
            // pictureBox24
            // 
            this.pictureBox24.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox24.Location = new System.Drawing.Point(426, 12);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(22, 22);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox24.TabIndex = 7;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.Tag = "coin";
            this.pictureBox24.Visible = false;
            // 
            // pictureBox37
            // 
            this.pictureBox37.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox37.Location = new System.Drawing.Point(426, 527);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(22, 22);
            this.pictureBox37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox37.TabIndex = 7;
            this.pictureBox37.TabStop = false;
            this.pictureBox37.Tag = "coin";
            this.pictureBox37.Visible = false;
            // 
            // pictureBox27
            // 
            this.pictureBox27.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox27.Location = new System.Drawing.Point(342, 113);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(22, 22);
            this.pictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox27.TabIndex = 7;
            this.pictureBox27.TabStop = false;
            this.pictureBox27.Tag = "coin";
            this.pictureBox27.Visible = false;
            // 
            // pictureBox31
            // 
            this.pictureBox31.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox31.Location = new System.Drawing.Point(426, 386);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(22, 22);
            this.pictureBox31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox31.TabIndex = 7;
            this.pictureBox31.TabStop = false;
            this.pictureBox31.Tag = "coin";
            this.pictureBox31.Visible = false;
            // 
            // pictureBox67
            // 
            this.pictureBox67.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox67.Location = new System.Drawing.Point(601, 11);
            this.pictureBox67.Name = "pictureBox67";
            this.pictureBox67.Size = new System.Drawing.Size(22, 22);
            this.pictureBox67.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox67.TabIndex = 7;
            this.pictureBox67.TabStop = false;
            this.pictureBox67.Tag = "coin";
            this.pictureBox67.Visible = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox12.Location = new System.Drawing.Point(94, 386);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(22, 22);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 7;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Tag = "coin";
            this.pictureBox12.Visible = false;
            // 
            // pictureBox23
            // 
            this.pictureBox23.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox23.Location = new System.Drawing.Point(426, 113);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(22, 22);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox23.TabIndex = 7;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.Tag = "coin";
            this.pictureBox23.Visible = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox20.Location = new System.Drawing.Point(261, 12);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(22, 22);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox20.TabIndex = 7;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Tag = "coin";
            this.pictureBox20.Visible = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox19.Location = new System.Drawing.Point(342, 12);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(22, 22);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox19.TabIndex = 7;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Tag = "coin";
            this.pictureBox19.Visible = false;
            // 
            // pictureBox66
            // 
            this.pictureBox66.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox66.Location = new System.Drawing.Point(560, 11);
            this.pictureBox66.Name = "pictureBox66";
            this.pictureBox66.Size = new System.Drawing.Size(22, 22);
            this.pictureBox66.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox66.TabIndex = 7;
            this.pictureBox66.TabStop = false;
            this.pictureBox66.Tag = "coin";
            this.pictureBox66.Visible = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox11.Location = new System.Drawing.Point(53, 386);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(22, 22);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 7;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Tag = "coin";
            this.pictureBox11.Visible = false;
            // 
            // pictureBox65
            // 
            this.pictureBox65.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox65.Location = new System.Drawing.Point(641, 11);
            this.pictureBox65.Name = "pictureBox65";
            this.pictureBox65.Size = new System.Drawing.Size(22, 22);
            this.pictureBox65.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox65.TabIndex = 7;
            this.pictureBox65.TabStop = false;
            this.pictureBox65.Tag = "coin";
            this.pictureBox65.Visible = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox10.Location = new System.Drawing.Point(134, 386);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(22, 22);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 7;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Tag = "coin";
            this.pictureBox10.Visible = false;
            // 
            // pictureBox64
            // 
            this.pictureBox64.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox64.Location = new System.Drawing.Point(560, 143);
            this.pictureBox64.Name = "pictureBox64";
            this.pictureBox64.Size = new System.Drawing.Size(22, 22);
            this.pictureBox64.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox64.TabIndex = 7;
            this.pictureBox64.TabStop = false;
            this.pictureBox64.Tag = "coin";
            this.pictureBox64.Visible = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox17.Location = new System.Drawing.Point(53, 518);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(22, 22);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 7;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Tag = "coin";
            this.pictureBox17.Visible = false;
            // 
            // pictureBox48
            // 
            this.pictureBox48.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox48.Location = new System.Drawing.Point(304, 262);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(22, 22);
            this.pictureBox48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox48.TabIndex = 7;
            this.pictureBox48.TabStop = false;
            this.pictureBox48.Tag = "coin";
            this.pictureBox48.Visible = false;
            // 
            // pictureBox63
            // 
            this.pictureBox63.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox63.Location = new System.Drawing.Point(601, 143);
            this.pictureBox63.Name = "pictureBox63";
            this.pictureBox63.Size = new System.Drawing.Size(22, 22);
            this.pictureBox63.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox63.TabIndex = 7;
            this.pictureBox63.TabStop = false;
            this.pictureBox63.Tag = "coin";
            this.pictureBox63.Visible = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox16.Location = new System.Drawing.Point(94, 518);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(22, 22);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 7;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Tag = "coin";
            this.pictureBox16.Visible = false;
            // 
            // pictureBox42
            // 
            this.pictureBox42.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox42.Location = new System.Drawing.Point(50, 262);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(22, 22);
            this.pictureBox42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox42.TabIndex = 7;
            this.pictureBox42.TabStop = false;
            this.pictureBox42.Tag = "coin";
            this.pictureBox42.Visible = false;
            // 
            // pictureBox62
            // 
            this.pictureBox62.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox62.Location = new System.Drawing.Point(641, 143);
            this.pictureBox62.Name = "pictureBox62";
            this.pictureBox62.Size = new System.Drawing.Size(22, 22);
            this.pictureBox62.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox62.TabIndex = 7;
            this.pictureBox62.TabStop = false;
            this.pictureBox62.Tag = "coin";
            this.pictureBox62.Visible = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox15.Location = new System.Drawing.Point(134, 518);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(22, 22);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 7;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Tag = "coin";
            this.pictureBox15.Visible = false;
            // 
            // pictureBox36
            // 
            this.pictureBox36.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox36.Location = new System.Drawing.Point(220, 527);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(22, 22);
            this.pictureBox36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox36.TabIndex = 7;
            this.pictureBox36.TabStop = false;
            this.pictureBox36.Tag = "coin";
            this.pictureBox36.Visible = false;
            // 
            // pictureBox61
            // 
            this.pictureBox61.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox61.Location = new System.Drawing.Point(641, 78);
            this.pictureBox61.Name = "pictureBox61";
            this.pictureBox61.Size = new System.Drawing.Size(22, 22);
            this.pictureBox61.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox61.TabIndex = 7;
            this.pictureBox61.TabStop = false;
            this.pictureBox61.Tag = "coin";
            this.pictureBox61.Visible = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox9.Location = new System.Drawing.Point(134, 453);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(22, 22);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 7;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Tag = "coin";
            this.pictureBox9.Visible = false;
            // 
            // pictureBox60
            // 
            this.pictureBox60.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox60.Location = new System.Drawing.Point(601, 78);
            this.pictureBox60.Name = "pictureBox60";
            this.pictureBox60.Size = new System.Drawing.Size(22, 22);
            this.pictureBox60.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox60.TabIndex = 7;
            this.pictureBox60.TabStop = false;
            this.pictureBox60.Tag = "coin";
            this.pictureBox60.Visible = false;
            // 
            // pictureBox30
            // 
            this.pictureBox30.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox30.Location = new System.Drawing.Point(220, 386);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(22, 22);
            this.pictureBox30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox30.TabIndex = 7;
            this.pictureBox30.TabStop = false;
            this.pictureBox30.Tag = "coin";
            this.pictureBox30.Visible = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox8.Location = new System.Drawing.Point(94, 453);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(22, 22);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 7;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Tag = "coin";
            this.pictureBox8.Visible = false;
            // 
            // pictureBox59
            // 
            this.pictureBox59.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox59.Location = new System.Drawing.Point(519, 143);
            this.pictureBox59.Name = "pictureBox59";
            this.pictureBox59.Size = new System.Drawing.Size(22, 22);
            this.pictureBox59.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox59.TabIndex = 7;
            this.pictureBox59.TabStop = false;
            this.pictureBox59.Tag = "coin";
            this.pictureBox59.Visible = false;
            // 
            // pictureBox26
            // 
            this.pictureBox26.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox26.Location = new System.Drawing.Point(220, 113);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(22, 22);
            this.pictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox26.TabIndex = 7;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.Tag = "coin";
            this.pictureBox26.Visible = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox14.Location = new System.Drawing.Point(12, 518);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(22, 22);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 7;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Tag = "coin";
            this.pictureBox14.Visible = false;
            // 
            // pictureBox58
            // 
            this.pictureBox58.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox58.Location = new System.Drawing.Point(519, 78);
            this.pictureBox58.Name = "pictureBox58";
            this.pictureBox58.Size = new System.Drawing.Size(22, 22);
            this.pictureBox58.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox58.TabIndex = 7;
            this.pictureBox58.TabStop = false;
            this.pictureBox58.Tag = "coin";
            this.pictureBox58.Visible = false;
            // 
            // pictureBox22
            // 
            this.pictureBox22.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox22.Location = new System.Drawing.Point(386, 12);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(22, 22);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox22.TabIndex = 7;
            this.pictureBox22.TabStop = false;
            this.pictureBox22.Tag = "coin";
            this.pictureBox22.Visible = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox13.Location = new System.Drawing.Point(12, 453);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(22, 22);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 7;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Tag = "coin";
            this.pictureBox13.Visible = false;
            // 
            // pictureBox57
            // 
            this.pictureBox57.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox57.Location = new System.Drawing.Point(560, 78);
            this.pictureBox57.Name = "pictureBox57";
            this.pictureBox57.Size = new System.Drawing.Size(22, 22);
            this.pictureBox57.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox57.TabIndex = 7;
            this.pictureBox57.TabStop = false;
            this.pictureBox57.Tag = "coin";
            this.pictureBox57.Visible = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox18.Location = new System.Drawing.Point(220, 12);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(22, 22);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 7;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Tag = "coin";
            this.pictureBox18.Visible = false;
            // 
            // pictureBox56
            // 
            this.pictureBox56.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox56.Location = new System.Drawing.Point(519, 11);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(22, 22);
            this.pictureBox56.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox56.TabIndex = 7;
            this.pictureBox56.TabStop = false;
            this.pictureBox56.Tag = "coin";
            this.pictureBox56.Visible = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::pac_man_code.Properties.Resources.coin;
            this.pictureBox7.Location = new System.Drawing.Point(53, 453);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(22, 22);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 7;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Tag = "coin";
            this.pictureBox7.Visible = false;
            // 
            // coin
            // 
            this.coin.Image = global::pac_man_code.Properties.Resources.coin;
            this.coin.Location = new System.Drawing.Point(12, 386);
            this.coin.Name = "coin";
            this.coin.Size = new System.Drawing.Size(22, 22);
            this.coin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coin.TabIndex = 7;
            this.coin.TabStop = false;
            this.coin.Tag = "coin";
            this.coin.Visible = false;
            // 
            // pacman
            // 
            this.pacman.Image = global::pac_man_code.Properties.Resources.right;
            this.pacman.Location = new System.Drawing.Point(31, 46);
            this.pacman.Name = "pacman";
            this.pacman.Size = new System.Drawing.Size(55, 55);
            this.pacman.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pacman.TabIndex = 6;
            this.pacman.TabStop = false;
            // 
            // pinkghost
            // 
            this.pinkghost.Image = global::pac_man_code.Properties.Resources._8480_pixelated_drake;
            this.pinkghost.Location = new System.Drawing.Point(487, 187);
            this.pinkghost.Name = "pinkghost";
            this.pinkghost.Size = new System.Drawing.Size(65, 65);
            this.pinkghost.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pinkghost.TabIndex = 5;
            this.pinkghost.TabStop = false;
            this.pinkghost.Tag = "ghost";
            this.pinkghost.Click += new System.EventHandler(this.pinkghost_Click);
            // 
            // yellowghost
            // 
            this.yellowghost.Image = global::pac_man_code.Properties.Resources._8480_pixelated_drake;
            this.yellowghost.Location = new System.Drawing.Point(315, 443);
            this.yellowghost.Name = "yellowghost";
            this.yellowghost.Size = new System.Drawing.Size(65, 65);
            this.yellowghost.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.yellowghost.TabIndex = 5;
            this.yellowghost.TabStop = false;
            this.yellowghost.Tag = "ghost";
            this.yellowghost.Click += new System.EventHandler(this.yellowghost_Click);
            // 
            // redghost
            // 
            this.redghost.Image = global::pac_man_code.Properties.Resources._8480_pixelated_drake;
            this.redghost.Location = new System.Drawing.Point(233, 40);
            this.redghost.Name = "redghost";
            this.redghost.Size = new System.Drawing.Size(65, 65);
            this.redghost.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.redghost.TabIndex = 5;
            this.redghost.TabStop = false;
            this.redghost.Tag = "ghost";
            this.redghost.Click += new System.EventHandler(this.redghost_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Blue;
            this.pictureBox6.Location = new System.Drawing.Point(172, 140);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(94, 25);
            this.pictureBox6.TabIndex = 4;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Tag = "wall";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Blue;
            this.pictureBox5.Location = new System.Drawing.Point(361, 355);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(138, 25);
            this.pictureBox5.TabIndex = 3;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Tag = "wall";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Blue;
            this.pictureBox4.Location = new System.Drawing.Point(463, 365);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(36, 247);
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Tag = "wall";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Blue;
            this.pictureBox2.Location = new System.Drawing.Point(463, -17);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(36, 182);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Tag = "wall";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Blue;
            this.pictureBox3.Location = new System.Drawing.Point(173, 386);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(35, 182);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Tag = "wall";
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Blue;
            this.pictureBox1.Location = new System.Drawing.Point(172, -17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(36, 182);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Tag = "wall";
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(684, 561);
            this.Controls.Add(this.pictureBox53);
            this.Controls.Add(this.pictureBox47);
            this.Controls.Add(this.pictureBox41);
            this.Controls.Add(this.pictureBox35);
            this.Controls.Add(this.pictureBox29);
            this.Controls.Add(this.pictureBox52);
            this.Controls.Add(this.pictureBox46);
            this.Controls.Add(this.pictureBox40);
            this.Controls.Add(this.pictureBox51);
            this.Controls.Add(this.pictureBox45);
            this.Controls.Add(this.pictureBox39);
            this.Controls.Add(this.pictureBox34);
            this.Controls.Add(this.pictureBox33);
            this.Controls.Add(this.pictureBox25);
            this.Controls.Add(this.pictureBox28);
            this.Controls.Add(this.pictureBox50);
            this.Controls.Add(this.pictureBox44);
            this.Controls.Add(this.pictureBox38);
            this.Controls.Add(this.pictureBox21);
            this.Controls.Add(this.pictureBox55);
            this.Controls.Add(this.pictureBox54);
            this.Controls.Add(this.pictureBox49);
            this.Controls.Add(this.pictureBox32);
            this.Controls.Add(this.pictureBox43);
            this.Controls.Add(this.pictureBox24);
            this.Controls.Add(this.pictureBox37);
            this.Controls.Add(this.pictureBox27);
            this.Controls.Add(this.pictureBox31);
            this.Controls.Add(this.pictureBox67);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox23);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.pictureBox66);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox65);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox64);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.pictureBox48);
            this.Controls.Add(this.pictureBox63);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.pictureBox42);
            this.Controls.Add(this.pictureBox62);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox36);
            this.Controls.Add(this.pictureBox61);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox60);
            this.Controls.Add(this.pictureBox30);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox59);
            this.Controls.Add(this.pictureBox26);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox58);
            this.Controls.Add(this.pictureBox22);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox57);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.pictureBox56);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.coin);
            this.Controls.Add(this.pacman);
            this.Controls.Add(this.pinkghost);
            this.Controls.Add(this.yellowghost);
            this.Controls.Add(this.redghost);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtScore);
            this.Name = "Form1";
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyisdown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.keyisup);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pacman)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pinkghost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yellowghost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.redghost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtScore;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox redghost;
        private System.Windows.Forms.PictureBox yellowghost;
        private System.Windows.Forms.PictureBox pinkghost;
        private System.Windows.Forms.PictureBox pacman;
        private System.Windows.Forms.PictureBox coin;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.PictureBox pictureBox57;
        private System.Windows.Forms.PictureBox pictureBox58;
        private System.Windows.Forms.PictureBox pictureBox59;
        private System.Windows.Forms.PictureBox pictureBox60;
        private System.Windows.Forms.PictureBox pictureBox61;
        private System.Windows.Forms.PictureBox pictureBox62;
        private System.Windows.Forms.PictureBox pictureBox63;
        private System.Windows.Forms.PictureBox pictureBox64;
        private System.Windows.Forms.PictureBox pictureBox65;
        private System.Windows.Forms.PictureBox pictureBox66;
        private System.Windows.Forms.PictureBox pictureBox67;
        private System.Windows.Forms.Timer gameTimer;
    }
}

